<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Exterior_house" tilewidth="140" tileheight="155" tilecount="1" columns="1">
 <image source="Exterior_house.png" width="203" height="209"/>
</tileset>
