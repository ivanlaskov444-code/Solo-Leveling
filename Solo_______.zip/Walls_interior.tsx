<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Walls_interior" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="craftpix-net-692491-free-glassblowers-workshop-top-down-pixel-art-asset/PNG/Walls_interior.png" width="256" height="272"/>
</tileset>
