<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Walls_street" tilewidth="32" tileheight="32" tilecount="90" columns="10">
 <image source="craftpix-net-692491-free-glassblowers-workshop-top-down-pixel-art-asset/PNG/Walls_street.png" width="336" height="288"/>
</tileset>
