<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Interior_objects" tilewidth="32" tileheight="32" spacing="2" tilecount="108" columns="6">
 <image source="craftpix-net-692491-free-glassblowers-workshop-top-down-pixel-art-asset/PNG/Interior_objects.png" width="208" height="624"/>
</tileset>
