<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="city" tilewidth="32" tileheight="32" tilecount="1040" columns="40">
 <image source="kenney_rpg-base/Spritesheet/RPGpack_sheet.png" width="1280" height="832"/>
</tileset>
