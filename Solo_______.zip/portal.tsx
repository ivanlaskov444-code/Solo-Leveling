<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="portal" tilewidth="32" tileheight="32" tilecount="8" columns="2">
 <image source="kenney_retro-textures-1/PNG/door_wood_window_lit.png" width="64" height="128"/>
</tileset>
