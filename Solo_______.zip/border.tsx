<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="border" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="kenney_retro-textures-1/PNG/window_square_metal.png" width="64" height="64"/>
</tileset>
